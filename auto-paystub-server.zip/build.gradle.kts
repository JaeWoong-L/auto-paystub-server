import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
	id("org.springframework.boot") version "2.7.0"
	id("io.spring.dependency-management") version "1.0.11.RELEASE"
	id("org.asciidoctor.jvm.convert") version "3.3.2"
	kotlin("jvm") version "1.6.10"
	kotlin("plugin.spring") version "1.6.10"
	kotlin("plugin.jpa") version "1.6.10"
}

fun String.toFile() = file(this)

val snippetsDir = "build/generated-snippets"
val docsResourcesDir = "src/main/resources/static/docs"
val asciidocDir = "build/asciidoc/html5"

allOpen {
	annotation("javax.persistence.Entity")
	annotation("javax.persistence.Embeddable")
	annotation("javax.persistence.MappedSuperclass")
}

group = "com.jw"
version = "0.0.1-SNAPSHOT"
java.sourceCompatibility = JavaVersion.VERSION_1_8

repositories {
	mavenCentral()
	maven(
        url = "https://repo.e-iceblue.com/nexus/content/groups/public/"
    )
}

dependencies {
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	implementation("mysql:mysql-connector-java")
	implementation("org.springframework.boot:spring-boot-starter-mustache")
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
	implementation("org.jetbrains.kotlin:kotlin-reflect")
	implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
	implementation("org.springframework.boot:spring-boot-starter-security")
	implementation("org.junit.jupiter:junit-jupiter:5.8.2")
	implementation("org.springframework.boot:spring-boot-starter-validation")
	developmentOnly("org.springframework.boot:spring-boot-devtools")
	runtimeOnly("com.h2database:h2")
	testImplementation("org.springframework.boot:spring-boot-starter-test")

	// jwt
	implementation("io.jsonwebtoken:jjwt-api:0.11.5")
	runtimeOnly("io.jsonwebtoken:jjwt-impl:0.11.5")
	runtimeOnly("io.jsonwebtoken:jjwt-jackson:0.11.5")

	// excel
	implementation("e-iceblue:spire.xls.free:5.1.0")
	implementation("org.apache.poi:poi:5.2.2")
	implementation("org.apache.poi:poi-ooxml:5.2.2")

	// test
	testImplementation("io.kotest:kotest-runner-junit5:5.3.1")
	testImplementation("io.kotest:kotest-assertions-core:5.3.1")
	testImplementation("io.kotest.extensions:kotest-extensions-spring:1.1.1")
	testImplementation("org.springframework.restdocs:spring-restdocs-mockmvc:2.0.6.RELEASE")

}

tasks.withType<KotlinCompile> {
	kotlinOptions {
		freeCompilerArgs = listOf("-Xjsr305=strict")
		jvmTarget = "1.8"
	}
}

tasks.withType<Test> {
	useJUnitPlatform()
}

tasks.test {
	outputs.dir(snippetsDir.toFile())
}

tasks.clean {
	delete(docsResourcesDir.toFile())
}

tasks.asciidoctor {
	inputs.dir(snippetsDir.toFile())
	dependsOn(tasks.test)

	doFirst {
		delete(docsResourcesDir.toFile())
	}
}

tasks.register<Copy>("copyHTML") {
    description = "Copy asciidoc html5 file to static resources"
    dependsOn(tasks.asciidoctor)

    from(asciidocDir.toFile())
    into(docsResourcesDir.toFile())
}

tasks.build {
    dependsOn(tasks.getByName("copyHTML"))
}

tasks.bootJar {
    dependsOn(tasks.asciidoctor, tasks.getByName("copyHTML"))
}
