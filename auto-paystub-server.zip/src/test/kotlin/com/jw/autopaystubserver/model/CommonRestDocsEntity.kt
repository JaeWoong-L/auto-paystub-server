package com.jw.autopaystubserver.model

import com.fasterxml.jackson.databind.ObjectMapper
import com.jw.autopaystubserver.JWTTokenProvider
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.mock.mockito.MockBean
import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext
import org.springframework.test.web.servlet.MockMvc

open class CommonRestDocsEntity() {
    @Autowired
    lateinit var mockMvc: MockMvc

    @Autowired
    lateinit var objectMapper: ObjectMapper

    // @EnableWebSecurity에 필요한 Bean을 mocking하기 위함.
    @MockBean
    lateinit var jwtTokenProvider: JWTTokenProvider

    // @EnableJpaAuditing에 필요한 Bean을 mocking하기 위함.
    @MockBean
    lateinit var jpaMetaModelMappingContest: JpaMetamodelMappingContext
}