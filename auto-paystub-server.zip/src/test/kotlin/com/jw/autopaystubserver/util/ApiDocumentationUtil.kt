package com.jw.autopaystubserver.util

import org.springframework.restdocs.operation.preprocess.OperationRequestPreprocessor
import org.springframework.restdocs.operation.preprocess.OperationResponsePreprocessor
import org.springframework.restdocs.operation.preprocess.Preprocessors

object ApiDocumentationUtil {
    fun getDocumentationRequest(): OperationRequestPreprocessor {
        return Preprocessors.preprocessRequest(
            Preprocessors.prettyPrint()
        )
    }

    fun getDocumentationResponse(): OperationResponsePreprocessor {
        return Preprocessors.preprocessResponse(
            Preprocessors.prettyPrint()
        )
    }
}