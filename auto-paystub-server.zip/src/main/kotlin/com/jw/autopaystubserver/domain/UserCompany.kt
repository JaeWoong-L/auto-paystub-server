package com.jw.autopaystubserver.domain

import javax.persistence.Entity
import javax.persistence.Table

//@Entity
//@Table(name = "user_company")
//class UserCompany {
//}