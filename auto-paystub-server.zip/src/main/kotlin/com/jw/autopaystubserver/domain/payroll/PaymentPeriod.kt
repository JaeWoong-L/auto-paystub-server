package com.jw.autopaystubserver.domain.payroll

enum class PaymentPeriod {
    DUMMY, MONTH, WEEK, DAY, HOUR
}