package com.jw.autopaystubserver.model

class ResponseEntity {
}