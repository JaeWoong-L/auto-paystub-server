package com.jw.autopaystubserver.util.exception

class BaseException(val exceptionResponse: ExceptionResponse): RuntimeException()